#ifndef CHECKIDENTICALELEMENTS_H
#define CHECKIDENTICALELEMENTS_H

bool checkIdenticalElements(int arraySize, const int firstArray[], const int secondArray[]);

#endif
