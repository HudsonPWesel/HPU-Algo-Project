#ifndef BUBBLESORT_H
#define BUBBLESORT_H

void bubbleSort(int S[], int n, long long& comparisons, bool ascending);

#endif
