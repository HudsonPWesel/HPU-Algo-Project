#ifndef QUICKSORT_H
#define QUICKSORT_H

void quickSort(int array[], int low, int high, long long &counter);

#endif
