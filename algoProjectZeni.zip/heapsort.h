#ifndef HEAPSORT_H
#define HEAPSORT_H
void myheapsort(int heap [], int lastHeapIndex, long long &counter);
#endif
