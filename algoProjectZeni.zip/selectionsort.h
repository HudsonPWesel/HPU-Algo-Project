#ifndef SELECTIONSORT_H
#define SELECTIONSORT_H

void selectionsort(int n, int S[], long long& comparisons, bool ascending);

#endif
