#ifndef INSERTION_H
#define INSERTION_H

void insertionsort(int arr[], int size, int& compares);

#endif
