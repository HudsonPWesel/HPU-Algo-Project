#ifndef MERGESORT_H
#define MERGESORT_H

void mergesort(int sizeBig, int bigArray[], bool ascending, long long &counter);

#endif
