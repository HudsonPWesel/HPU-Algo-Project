#ifndef CHECKSORTED_H
#define CHECKSORTED_H

bool checkSorted(const int arraySize, const int checkArray[], bool ascending);

#endif
